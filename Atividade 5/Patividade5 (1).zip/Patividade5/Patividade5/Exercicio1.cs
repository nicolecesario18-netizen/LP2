﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmEx1 : Form
    {
        public frmEx1()
        {
            InitializeComponent();
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            {
                string texto = txtPalavra.Text;
                int contEspacos = 0;

                for (int i = 0; i < texto.Length; i++)
                {
                    if (texto[i] == ' ')
                    {
                        contEspacos++;
                    }
                }
                MessageBox.Show($"Número de espaços em branco: {contEspacos}");
            }
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            string texto = txtPalavra.Text.ToUpper();
            int contR = 0;
            int i = 0;

            while (i < texto.Length)
            {
                if (texto[i] == 'R')
                {
                    contR++;
                }
                i++;
            }
            MessageBox.Show($"Número de vezes que aparece a letra 'R': {contR}");
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            string texto = txtPalavra.Text.ToLower();
            int contPares = 0;

            if (texto.Length > 1)
            {
                int i = 0;
                do
                {
                    // Verifica se é uma letra e se é igual à próxima letra
                    if (char.IsLetter(texto[i]) && texto[i] == texto[i + 1])
                    {
                        contPares++;
                    }
                    i++;
                } while (i < texto.Length - 1);
            }
            MessageBox.Show($"Número de pares de letras: {contPares}");
        }

    }
}

