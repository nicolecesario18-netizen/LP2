﻿namespace PCal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.lbl3 = new System.Windows.Forms.Label();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn1 = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.Btn4 = new System.Windows.Forms.Button();
            this.Btn5 = new System.Windows.Forms.Button();
            this.Btn6 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(79, 108);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(78, 20);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Numero 1";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(79, 184);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(78, 20);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Numero 2";
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(270, 184);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(189, 26);
            this.txt2.TabIndex = 2;
            this.txt2.Validated += new System.EventHandler(this.txt2_Validated);
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(270, 108);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(189, 26);
            this.txt1.TabIndex = 3;
            this.txt1.Validated += new System.EventHandler(this.txt1_Validated);
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(79, 264);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(82, 20);
            this.lbl3.TabIndex = 4;
            this.lbl3.Text = "Resultado";
            // 
            // txt3
            // 
            this.txt3.Enabled = false;
            this.txt3.Location = new System.Drawing.Point(270, 258);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(189, 26);
            this.txt3.TabIndex = 5;
            this.txt3.Validated += new System.EventHandler(this.txt3_Validated);
            // 
            // Btn2
            // 
            this.Btn2.Location = new System.Drawing.Point(608, 234);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(179, 63);
            this.Btn2.TabIndex = 6;
            this.Btn2.Text = "Sair";
            this.Btn2.UseVisualStyleBackColor = true;
            this.Btn2.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // Btn1
            // 
            this.Btn1.Location = new System.Drawing.Point(608, 99);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(179, 59);
            this.Btn1.TabIndex = 7;
            this.Btn1.Text = "Limpar";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.Btn1_Click);
            // 
            // Btn3
            // 
            this.Btn3.Location = new System.Drawing.Point(83, 366);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(126, 75);
            this.Btn3.TabIndex = 8;
            this.Btn3.Text = "+";
            this.Btn3.UseVisualStyleBackColor = true;
            this.Btn3.Click += new System.EventHandler(this.Btn3_Click);
            // 
            // Btn4
            // 
            this.Btn4.Location = new System.Drawing.Point(260, 366);
            this.Btn4.Name = "Btn4";
            this.Btn4.Size = new System.Drawing.Size(130, 75);
            this.Btn4.TabIndex = 9;
            this.Btn4.Text = "-";
            this.Btn4.UseVisualStyleBackColor = true;
            this.Btn4.Click += new System.EventHandler(this.Btn4_Click);
            // 
            // Btn5
            // 
            this.Btn5.Location = new System.Drawing.Point(456, 366);
            this.Btn5.Name = "Btn5";
            this.Btn5.Size = new System.Drawing.Size(130, 75);
            this.Btn5.TabIndex = 10;
            this.Btn5.Text = "*";
            this.Btn5.UseVisualStyleBackColor = true;
            this.Btn5.Click += new System.EventHandler(this.Btn5_Click);
            // 
            // Btn6
            // 
            this.Btn6.Location = new System.Drawing.Point(657, 366);
            this.Btn6.Name = "Btn6";
            this.Btn6.Size = new System.Drawing.Size(130, 75);
            this.Btn6.TabIndex = 11;
            this.Btn6.Text = "/";
            this.Btn6.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1106, 615);
            this.Controls.Add(this.Btn6);
            this.Controls.Add(this.Btn5);
            this.Controls.Add(this.Btn4);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.Btn1);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.Button Btn3;
        private System.Windows.Forms.Button Btn4;
        private System.Windows.Forms.Button Btn5;
        private System.Windows.Forms.Button Btn6;
    }
}

