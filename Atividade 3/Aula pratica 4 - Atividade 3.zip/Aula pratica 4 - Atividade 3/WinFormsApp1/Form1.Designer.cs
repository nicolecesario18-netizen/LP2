﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblLadoA = new Label();
            lblLadoB = new Label();
            lblLadoC = new Label();
            bntExecutar = new Button();
            bntLimpar = new Button();
            mskbxLadoA = new MaskedTextBox();
            mskbxLadoB = new MaskedTextBox();
            mskbxLadoC = new MaskedTextBox();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblLadoA
            // 
            lblLadoA.AutoSize = true;
            lblLadoA.Location = new Point(147, 163);
            lblLadoA.Name = "lblLadoA";
            lblLadoA.Size = new Size(68, 25);
            lblLadoA.TabIndex = 0;
            lblLadoA.Text = "Lado A";
            // 
            // lblLadoB
            // 
            lblLadoB.AutoSize = true;
            lblLadoB.Location = new Point(147, 251);
            lblLadoB.Name = "lblLadoB";
            lblLadoB.Size = new Size(66, 25);
            lblLadoB.TabIndex = 1;
            lblLadoB.Text = "Lado B";
            // 
            // lblLadoC
            // 
            lblLadoC.AutoSize = true;
            lblLadoC.Location = new Point(147, 337);
            lblLadoC.Name = "lblLadoC";
            lblLadoC.Size = new Size(67, 25);
            lblLadoC.TabIndex = 2;
            lblLadoC.Text = "Lado C";
            // 
            // bntExecutar
            // 
            bntExecutar.Location = new Point(147, 485);
            bntExecutar.Name = "bntExecutar";
            bntExecutar.Size = new Size(112, 34);
            bntExecutar.TabIndex = 3;
            bntExecutar.Text = "Executar";
            bntExecutar.UseVisualStyleBackColor = true;
            bntExecutar.Click += bntExecutar_Click;
            // 
            // bntLimpar
            // 
            bntLimpar.Location = new Point(455, 485);
            bntLimpar.Name = "bntLimpar";
            bntLimpar.Size = new Size(112, 34);
            bntLimpar.TabIndex = 4;
            bntLimpar.Text = "Limpar";
            bntLimpar.UseVisualStyleBackColor = true;
            bntLimpar.Click += bntLimpar_Click;
            // 
            // mskbxLadoA
            // 
            mskbxLadoA.Location = new Point(455, 163);
            mskbxLadoA.Mask = "00.00";
            mskbxLadoA.Name = "mskbxLadoA";
            mskbxLadoA.Size = new Size(150, 31);
            mskbxLadoA.TabIndex = 5;
            mskbxLadoA.Validated += mskbxLadoA_Validated;
            // 
            // mskbxLadoB
            // 
            mskbxLadoB.Location = new Point(455, 245);
            mskbxLadoB.Mask = "00.00";
            mskbxLadoB.Name = "mskbxLadoB";
            mskbxLadoB.Size = new Size(150, 31);
            mskbxLadoB.TabIndex = 6;
            mskbxLadoB.Validated += mskbxLadoB_Validated;
            // 
            // mskbxLadoC
            // 
            mskbxLadoC.Location = new Point(455, 331);
            mskbxLadoC.Mask = "00.00";
            mskbxLadoC.Name = "mskbxLadoC";
            mskbxLadoC.Size = new Size(150, 31);
            mskbxLadoC.TabIndex = 7;
            mskbxLadoC.Validated += mskbxLadoC_Validated;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(767, 485);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1054, 617);
            Controls.Add(btnSair);
            Controls.Add(mskbxLadoC);
            Controls.Add(mskbxLadoB);
            Controls.Add(mskbxLadoA);
            Controls.Add(bntLimpar);
            Controls.Add(bntExecutar);
            Controls.Add(lblLadoC);
            Controls.Add(lblLadoB);
            Controls.Add(lblLadoA);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLadoA;
        private Label lblLadoB;
        private Label lblLadoC;
        private Button bntExecutar;
        private Button bntLimpar;
        private MaskedTextBox mskbxLadoA;
        private MaskedTextBox mskbxLadoB;
        private MaskedTextBox mskbxLadoC;
        private Button btnSair;
    }
}
