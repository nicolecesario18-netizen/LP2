﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[]vetor = new int[20];
            string aux = " ";
            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o numero {i + 1}", "Entrada de dados");
                if(!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor invalido");
                    i--;
                }
               
            }
            Array.Reverse(vetor);
            aux = " ";
            foreach (int x in vetor)
                aux += x+ "\n";
            MessageBox.Show(aux);
        }



        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Beatriz");
            alunos.Add("Camila");
            alunos.Add("João");
            alunos.Add("Joana");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");
           
            alunos.Remove("Otávio");
            string resultado = string.Join("\n", alunos.Cast<string>()); 
            MessageBox.Show(resultado);

        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {

        }
    }
}
