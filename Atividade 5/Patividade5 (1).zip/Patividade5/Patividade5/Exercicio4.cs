﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void btnCalcSalario_Click(object sender, EventArgs e)
        {
            try
            {
                // Leitura de dados
                string nome = txtNome.Text;
                string matricula = txtMatricula.Text;
                int producao = int.Parse(txtProducao.Text);
                double salarioA = double.Parse(txtSalarioBase.Text);
                double gratificacao = double.Parse(txtGratificacao.Text);

                int B = (producao >= 100) ? 1 : 0;
                int C = (producao >= 120) ? 1 : 0;
                int D = (producao >= 150) ? 1 : 0;

                double salarioBruto = salarioA + salarioA * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

                if (salarioBruto > 7000.00)
                {
                    bool atendeRequisitosEspeciais = (producao >= 150 && gratificacao > 0);

                    if (!atendeRequisitosEspeciais)
                    {
                        salarioBruto = 7000.00;
                    }
                }

                MessageBox.Show(
                    $"Funcionário: {nome}\n" +
                    $"Matrícula: {matricula}\n" +
                    $"Salário Bruto: R$ {salarioBruto.ToString("F2")}"
                );
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, preencha os campos numéricos corretamente.");
            }
        }
    }
}
