﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmEx4 : Form
    {
        public frmEx4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNum.Text, out int n) && n > 0)
            {
                double H = 0;

                for (double i = 1; i <= n; i++)
                {
                    H += 1.0 / i;
                }

                MessageBox.Show($"O valor de H é: {H.ToString("F4")}");
            }
            else
            {
                MessageBox.Show("Por favor, insira um número inteiro maior que 0.");
            }
        }
    }
}
