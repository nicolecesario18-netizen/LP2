﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace Pvestibular02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceberDados_Click(object sender, EventArgs e)
        {
            int[,] valores = new int[2, 5];
            string aux = "";


            for (int linha = 0; linha < 2; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++) //percorrendo todos os valores da primera linha
                {

                    aux = Interaction.InputBox($"Ano {linha + 1 }: Curso{coluna + 1} ", "Entrada de dados");
                    if (!int.TryParse(aux, out valores[linha, coluna]))
                    {
                        MessageBox.Show("Valor invalido, digite novamente");
                        coluna--;

                    }

                }

            }

            int totalAlunosCurso = 0;
            int totalGeral = 0;

            for (int linha = 0; linha < 2; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++)
                {
                    totalAlunosCurso = (valores[linha, 0] + valores[linha, 1] + valores[linha, 2] + valores[linha, 3] + valores[linha, 4]);
                    totalGeral += totalAlunosCurso;

                    
                    lstbxCursoalunos.Items.Add($"Total do Curso {(linha+1)} do ano {(coluna+1)} : {(totalAlunosCurso)}");

                }
                lstbxCursoalunos.Items.Add("-------------------------------------------------------------------");

            }
            lstbxCursoalunos.Items.Add("-------------------------------------------------------------------");
            lstbxCursoalunos.Items.Add($"Total Geral : {(totalGeral)}");

        }




        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxCursoalunos.Items.Clear();
        }
    }
}
