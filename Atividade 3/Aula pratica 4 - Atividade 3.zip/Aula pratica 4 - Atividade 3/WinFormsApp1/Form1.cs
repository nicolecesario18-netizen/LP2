using System.Diagnostics.Eventing.Reader;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxLadoA.Text, out ladoA))
            {
                MessageBox.Show("Lado invalido");
                mskbxLadoA.Focus();
            }

        }

        private void mskbxLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxLadoB.Text, out ladoB))
            {
                MessageBox.Show("Lado invalido");
                mskbxLadoB.Focus();
            }
        }

        private void mskbxLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxLadoC.Text, out ladoC))
            {
                MessageBox.Show("Lado invalido");
                mskbxLadoC.Focus();
            }
        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            mskbxLadoA.Clear();
            mskbxLadoB.Clear();
            mskbxLadoC.Clear();
            ladoA = 0;
            ladoC = 0;
            ladoB = 0;

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void bntExecutar_Click(object sender, EventArgs e)
        {
            if ((ladoA < (ladoB + ladoC)) && (ladoA > (Math.Abs(ladoB - ladoC))) &&
                (ladoB < (ladoA + ladoC)) && (ladoB > (Math.Abs(ladoA - ladoC))) &&
                (ladoC < (ladoA + ladoB)) && (ladoC > (Math.Abs(ladoA - ladoB))))
            {
                if (ladoA == ladoB && ladoB == ladoC)
                    MessageBox.Show("Triangulo Equilatero");
                else if (ladoA == ladoB || ladoB == ladoC || ladoA == ladoC)
                    MessageBox.Show("Triangulo Isoseles");
                else
                    MessageBox.Show("Triangulo Escaleno");
            }
            else
                MessageBox.Show("Os valores nao resultam em um triangulo");


        }
    }
}

