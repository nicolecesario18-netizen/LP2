﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmEx3 : Form
    {
        public frmEx3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string texto = txtFrase.Text;

            if (string.IsNullOrWhiteSpace(texto))
            {
                MessageBox.Show("Digite uma frase.");
                return;
            }

            string textoSemAcento = new string(texto
                .Normalize(NormalizationForm.FormD)
                .Where(ch => char.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark)
                .ToArray());

            string textoLimpo = textoSemAcento.Replace(" ", "").ToUpper();

            char[] arrayCaracteres = textoLimpo.ToCharArray();
            Array.Reverse(arrayCaracteres);
            string textoInvertido = new string(arrayCaracteres);

            if (textoLimpo == textoInvertido)
            {
                MessageBox.Show($"A frase digitada é um PALÍNDROMO!\n{textoLimpo} = {textoInvertido}");
            }
            else
            {
                MessageBox.Show("A frase não é um palíndromo.");
            }
        }
    }
}
