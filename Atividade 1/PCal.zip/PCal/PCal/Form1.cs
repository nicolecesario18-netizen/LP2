﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace PCal
{ 

    public partial class Form1 : Form
        
    { Double Numero1, Numero2, Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txt2_Validated(object sender, EventArgs e)
        {
            if(this.ActiveControl==Btn2)
            if (!double.TryParse(txt2.Text, out Numero2))
            {
                MessageBox.Show("Numero invalido Digite novamente");
                    txt2.Focus();
            }


        }

        private void Btn2_Validated(object sender, EventArgs e)
        {
            
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
           txt3.Text = Numero1 + Numero2;
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            txt3.Text = Numero1 - Numero2;
               
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            txt3.Text = Numero1 * Numero2;
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            txt1.Clear();   
            txt2.Clear();   
            txt3.Clear();   
            
        }

        private void txt3_Validated(object sender, EventArgs e)
        {
                 
        }

        private void txt1_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == Btn2)
                if (!double.TryParse(txt1.Text, out Numero1))
            {
                MessageBox.Show("Numero invalido Digite novamente");
                    txt1.Focus();
            }
        }
    }
}
